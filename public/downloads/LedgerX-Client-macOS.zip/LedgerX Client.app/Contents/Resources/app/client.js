
const { app, BrowserWindow } = require('electron');
app.whenReady().then(() => {
  const win = new BrowserWindow({
    width: 1366,
    height: 768,
    title: 'LedgerX LAN Client',
    autoHideMenuBar: true
  });
  const url = process.argv[2] || 'http://127.0.0.1:45454/?lan_client=1';
  win.loadURL(url);
});

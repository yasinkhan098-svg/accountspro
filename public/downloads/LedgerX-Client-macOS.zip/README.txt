LedgerX LAN Client for macOS (Apple Silicon & Intel)
=====================================================

INSTALLATION INSTRUCTIONS:
1. Drag 'LedgerX Client.app' into your Mac's 'Applications' folder.
2. Double-click 'LedgerX Client' to launch your billing counter terminal.
3. The app automatically discovers the Host PC on your local Wi-Fi/LAN on Port 45454.
4. No IP configuration or license key required on client terminals!

Cashier roles, POS sales, barcodes, and thermal printing work live in real-time.

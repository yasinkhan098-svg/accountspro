LedgerX Online Cloud Client for macOS
=====================================

INSTALLATION INSTRUCTIONS:
1. Drag 'LedgerX Cloud Client.app' into your 'Applications' folder.
2. Launch to open your secure cloud accounting session instantly.

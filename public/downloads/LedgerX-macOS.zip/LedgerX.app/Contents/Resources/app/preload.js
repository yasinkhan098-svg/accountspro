const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktopBridge', {
  isDesktopApp: true,
  getMachineId: () => ipcRenderer.invoke('get-machine-id'),
  checkClockRollback: () => ipcRenderer.invoke('check-clock-rollback'),
  getOfflineToken: () => ipcRenderer.invoke('get-offline-token'),
  saveOfflineToken: (token) => ipcRenderer.invoke('save-offline-token', token),
  recordTimeGuard: () => ipcRenderer.invoke('record-time-guard'),
  saveDataFile: (data) => ipcRenderer.invoke('save-data-file', data),
  loadDataFile: () => ipcRenderer.invoke('load-data-file'),
  openDataFolder: () => ipcRenderer.invoke('open-data-folder'),
  getDataPath: () => ipcRenderer.invoke('get-data-path'),
  scanCompanyFolders: () => ipcRenderer.invoke('scan-company-folders'),
  loadCompanyFolder: (code) => ipcRenderer.invoke('load-company-folder', code),
  saveCompanyFolder: (data) => ipcRenderer.invoke('save-company-folder', data),
  syncStatus: (status) => ipcRenderer.send('sync-status-update', status),
  onSyncTrigger: (callback) => ipcRenderer.on('trigger-sync', () => callback()),
  printDocument: (options) => ipcRenderer.invoke('print-document', options),
});

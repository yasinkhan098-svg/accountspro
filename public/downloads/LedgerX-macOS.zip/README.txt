LedgerX Desktop for macOS (Apple Silicon & Intel)
=================================================

INSTALLATION INSTRUCTIONS:
1. Drag 'LedgerX.app' into your Mac's 'Applications' folder.
2. Open Applications and double-click 'LedgerX' to launch.
3. Enter your License Key once to activate 100% offline access.

Features:
- Full Offline Accounting & Tally-style Multi-Company Storage
- POS Counter, Thermal Slip Printing, and Barcode Scanning
- Multi-User LAN Client / Host Connectivity on Port 45454
- 100% Feature Parity with Windows Edition

Support: support@ledgerxerp.com | https://www.ledgerxerp.com
